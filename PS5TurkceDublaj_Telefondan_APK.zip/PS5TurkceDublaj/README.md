# PS5 Türkçe Dublaj — Android prototip 0.1

Bu proje, televizyon hoparlöründen gelen İngilizce konuşmayı telefon mikrofonuyla algılayıp Türkçeye çevirmeyi ve Android TTS ile seslendirmeyi amaçlayan ilk prototiptir.

## Özellikler
- İngilizce (ABD) konuşma tanıma ve kısmi sonuçlar
- MyMemory üzerinden çevrimiçi İngilizce-Türkçe çeviri
- Android'in yüklü Türkçe metin-okuma sesiyle seslendirme
- Başlat/durdur, algılanan metin, çeviri ve konuşma hızı kontrolü

## Gereksinimler
- Android Studio (Koala veya daha yeni)
- JDK 17
- Android SDK 35
- Android 8.0+ telefon

## Derleme
Android Studio ile klasörü açın, Gradle senkronizasyonunu tamamlayın ve `app` yapılandırmasını telefona çalıştırın. APK için: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Bilinen sınırlamalar
- Bu ilk prototip gerçek zamanlı profesyonel dublaj kalitesinde değildir. Konuşma tanıma servisinin gecikmesi, TV'nin müzik/efektleri ve çeviri servisi nedeniyle birkaç saniye veya daha fazla gecikme olabilir.
- Android konuşma tanıma servisinin kullanılabilirliği ve kalitesi telefona/Google hizmetlerine bağlıdır.
- MyMemory ücretsiz uç noktasının kota ve kullanım koşulları değişebilir; yoğun kullanım için uygun değildir.
- Telefon hoparlöründen çıkan Türkçe ses mikrofona geri girebilir. İlk testte telefon sesini düşük tutun; kulaklık kullanmak geri beslemeyi azaltır ancak amaç telefon hoparlörüyse akustik yankı giderme sonraki sürümde ele alınmalıdır.
- İlk sürüm uygulama ekrandayken çalışır; ekran kapalıyken/arka planda kesintisiz çalışma henüz eklenmemiştir.
- GTA 5/GTA 6'ya özel entegrasyon yoktur; TV'den duyulan İngilizce konuşmayı genel olarak algılamayı hedefler.

## Gizlilik
Konuşma tanıma Android cihazın varsayılan tanıma sağlayıcısına, metin çevirisi MyMemory servisine gönderilebilir. Hassas konuşmaları test etmeyin. Üretim sürümünde servis sağlayıcısı ve gizlilik ayarları açıkça seçilebilir olmalıdır.

## Yalnızca Android telefonla APK oluşturma

Bilgisayarın yoksa `TELEFONDAN_APK_OLUSTURMA.txt` dosyasındaki adımları izle. Proje, GitHub Actions üzerinde bulutta derlenebilir. APK otomatik olarak Actions çalışmasının Artifacts bölümüne yüklenir.
