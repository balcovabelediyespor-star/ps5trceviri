package com.example.ps5turkcedublaj

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var translated: TextView
    private lateinit var startButton: Button
    private lateinit var speech: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var running = false
    private var lastSubmitted = ""
    private var lastPartial = ""
    private var voiceRate = 1.0f
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        tts = TextToSpeech(this, this)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Bu telefonda konuşma tanıma hizmeti bulunamadı."
            startButton.isEnabled = false
        } else {
            speech = SpeechRecognizer.createSpeechRecognizer(this)
            speech.setRecognitionListener(listener)
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF101827.toInt())
        }
        val title = TextView(this).apply {
            text = "🎮  PS5 TÜRKÇE DUBLAJ"
            textSize = 23f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
        }
        root.addView(title, lp(-1, -2))
        val sub = TextView(this).apply {
            text = "TV sesini dinle • İngilizce → Türkçe"
            textSize = 14f; setTextColor(0xFFB7C4D8.toInt()); gravity = Gravity.CENTER
            setPadding(0, 10, 0, 24)
        }
        root.addView(sub, lp(-1, -2))
        status = cardText("Hazır · TV sesini telefona duyur")
        root.addView(status, lp(-1, -2, 0, 8))
        startButton = Button(this).apply {
            text = "DİNLEMEYİ BAŞLAT"
            setOnClickListener { if (running) stopListening() else startListening() }
        }
        root.addView(startButton, lp(-1, 58, 0, 12))
        val volumeTitle = TextView(this).apply {
            text = "Türkçe dublaj ses seviyesi"; textSize = 14f; setTextColor(0xFFFFFFFF.toInt())
            setPadding(2, 12, 0, 0)
        }
        root.addView(volumeTitle, lp(-1, -2))
        val volume = SeekBar(this).apply {
            max = 100; progress = 85
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { voiceRate = 0.75f + (p / 100f) * 0.55f; if (ttsReady) tts.setSpeechRate(voiceRate) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(volume, lp(-1, -2))
        root.addView(section("ALGILANAN İNGİLİZCE"), lp(-1, -2, 0, 14))
        heard = cardText("Henüz konuşma algılanmadı.")
        root.addView(heard, lp(-1, -2, 0, 8))
        root.addView(section("TÜRKÇE DUBLAJ"), lp(-1, -2, 0, 14))
        translated = cardText("Çeviri burada görünecek.")
        root.addView(translated, lp(-1, -2, 0, 8))
        val note = TextView(this).apply {
            text = "Not: İlk prototip konuşma tanıma + çevrimiçi çeviri + telefonun Türkçe sesini kullanır. Kısa gecikme ve ortam yankısı olabilir."
            textSize = 12f; setTextColor(0xFF91A0B8.toInt()); setPadding(2, 18, 2, 0)
        }
        root.addView(note, lp(-1, -2))
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(w, h).apply { setMargins(0, top, 0, bottom) }
    private fun cardText(value: String) = TextView(this).apply {
        text = value; textSize = 16f; setTextColor(0xFFFFFFFF.toInt())
        setPadding(16, 16, 16, 16); setBackgroundColor(0xFF202C40.toInt())
    }
    private fun section(value: String) = TextView(this).apply {
        text = value; textSize = 12f; setTextColor(0xFF55D6A4.toInt())
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { main.post { status.text = "Dinliyorum… TV'deki konuşmayı algılamaya çalışıyorum." } }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { restartRecognition() }
        override fun onError(error: Int) { if (running) restartRecognition(650) }
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            submitIfNew(text)
            if (running) restartRecognition(250)
        }
        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            if (text.isNotBlank()) {
                lastPartial = text
                main.post { heard.text = text }
                // Parçalı tanıma metni sık sık değiştiğinden yalnızca cümle sonuna benzeyen
                // noktalama geldiğinde gönderilir; nihai sonuçta tekrar kontrol edilir.
                if (text.matches(Regex(".*[.!?]$"))) submitIfNew(text)
            }
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun recognizerIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41); return
        }
        running = true; lastSubmitted = ""; lastPartial = ""
        startButton.text = "DİNLEMEYİ DURDUR"
        status.text = "Mikrofon açılıyor…"
        startRecognition()
    }
    private fun startRecognition() {
        if (!running || isFinishing) return
        try { speech.startListening(recognizerIntent()) } catch (_: Exception) { restartRecognition(900) }
    }
    private fun restartRecognition(delay: Long = 350) {
        if (!running) return
        main.postDelayed({ if (running) { try { speech.cancel(); speech.startListening(recognizerIntent()) } catch (_: Exception) { restartRecognition(1000) } } }, delay)
    }
    private fun stopListening() {
        running = false
        try { speech.cancel() } catch (_: Exception) {}
        if (ttsReady) tts.stop()
        startButton.text = "DİNLEMEYİ BAŞLAT"
        status.text = "Durduruldu."
    }

    private fun submitIfNew(raw: String) {
        val clean = raw.trim().replace(Regex("\\s+"), " ")
        if (clean.length < 5) return
        val normalized = clean.lowercase(Locale.US).trimEnd('.', '!', '?', ',')
        if (normalized == lastSubmitted || normalized.startsWith(lastSubmitted) && lastSubmitted.length > 12) return
        lastSubmitted = normalized
        main.post { heard.text = clean; status.text = "Çevriliyor…" }
        worker.execute {
            val result = translate(clean)
            main.post {
                if (result != null) {
                    translated.text = result
                    status.text = if (running) "Dinliyorum…" else "Çeviri hazır."
                    if (ttsReady && running) tts.speak(result, TextToSpeech.QUEUE_ADD, null, "dub-${System.nanoTime()}")
                } else status.text = "Çeviri alınamadı. İnternet bağlantısını kontrol et."
            }
        }
    }

    // MyMemory ücretsiz deneme uç noktasıdır; kullanım/karakter limitleri değişebilir.
    private fun translate(text: String): String? {
        var connection: HttpURLConnection? = null
        return try {
            val encoded = URLEncoder.encode(text.take(450), "UTF-8")
            val url = URL("https://api.mymemory.translated.net/get?q=$encoded&langpair=en|tr")
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 7000; readTimeout = 7000
                setRequestProperty("User-Agent", "PS5TurkceDublaj/0.1")
            }
            if (connection.responseCode !in 200..299) return null
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            val response = json.optJSONObject("responseData")?.optString("translatedText").orEmpty()
            response.takeIf { it.isNotBlank() && it != "QUERY LENGTH LIMIT EXCEEDED" }
                ?.replace("&quot;", "\"")?.replace("&#39;", "'")?.replace("&amp;", "&")
        } catch (_: Exception) { null } finally { connection?.disconnect() }
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts.setLanguage(Locale("tr", "TR"))
            tts.setSpeechRate(voiceRate)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                status.text = "Telefonda Türkçe ses paketi yok. Android Ayarları > Metin okuma bölümünden Türkçe ses yükle."
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) status.text = "Mikrofon izni verildi. Başlatabilirsin."
    }

    override fun onDestroy() {
        running = false
        if (::speech.isInitialized) speech.destroy()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        worker.shutdownNow()
        super.onDestroy()
    }
}
